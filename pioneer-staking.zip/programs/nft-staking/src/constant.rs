pub const GLOBAL_AUTHORITY_SEED: &str = "global-authority";
pub const USER_POOL_SEED: &str = "user-stake-pool";

pub const COLLECTION_ADDRESS: &str = "G2sc5mU3eLRkbRupnupzB3NTzZ85bnc9L1ReAre9dzFU";

pub const MAX_STAKE_AMOUNT: u16 = 50;

pub const DAY_SECONDS: i64 = 60 * 60 * 24;
